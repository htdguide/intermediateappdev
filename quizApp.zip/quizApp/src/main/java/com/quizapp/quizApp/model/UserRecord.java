package com.quizapp.quizApp.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "UserRecord")
public class UserRecord implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_record_id")
    private Long userRecordId;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference(value = "user-reference")
    private User user;

    @ManyToOne
    @JoinColumn(name = "quiz_id", nullable = false)
    @JsonBackReference(value = "quiz-reference")
    private Quiz quiz;


    @Column(name = "score", nullable = false)
    private Integer score;

    @Column(name = "played_at", nullable = false)
    private LocalDateTime playedAt;

    public UserRecord() {}

    public UserRecord(User user, Quiz quiz, Integer score, LocalDateTime playedAt) {
        this.user = user;
        this.quiz = quiz;
        this.score = score;
        this.playedAt = playedAt;
    }

    public Long getUserRecordId() {
        return userRecordId;
    }

    public void setUserRecordId(Long userRecordId) {
        this.userRecordId = userRecordId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Quiz getQuiz() {
        return quiz;
    }

    public void setQuiz(Quiz quiz) {
        this.quiz = quiz;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public LocalDateTime getPlayedAt() {
        return playedAt;
    }

    public void setPlayedAt(LocalDateTime playedAt) {
        this.playedAt = playedAt;
    }

    // Add these helper methods
    public Long getUserId() {
        return user != null ? user.getUserId() : null;
    }

    public Long getQuizId() {
        return quiz != null ? quiz.getQuizId() : null;
    }
}