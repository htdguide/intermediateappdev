package com.quizapp.quizApp.model;

public enum UserType {
    ADMIN,
    PLAYER
}
