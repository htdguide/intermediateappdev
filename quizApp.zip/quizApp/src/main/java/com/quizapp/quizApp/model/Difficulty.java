package com.quizapp.quizApp.model;

public enum Difficulty {
    easy,
    medium,
    hard
}
